export const allRoles = [
  {
    id: 1,
    code: 1,
    name: "超级管理员",
    author: "1,2,3,4,5",
    note: "全平台管理"
  },
  {
    id: 2,
    code: 2,
    name: "业务员",
    author: "1,2,3,4,5",
    note: "业务办理"
  },
  {
    id: 3,
    code: 3,
    name: "安装员",
    author: "1,2,3,4,5",
    note: "安装处理"
  }
];

export default {
  allRoles
};
