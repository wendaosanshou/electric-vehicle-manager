import Vue from 'vue'
import { $apis, $util } from '@/helper'
import VueRouter from 'vue-router';

Vue.prototype.$apis = $apis
Vue.prototype.$util = $util