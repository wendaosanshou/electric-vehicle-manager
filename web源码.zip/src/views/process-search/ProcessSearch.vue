<template>
  <div class="process-search">
      <RecordInfoManage/>
  </div>
</template>

<script>
import RecordInfoManage from '../record-info-manage/RecordInfoManage'

export default {
    components: {
        RecordInfoManage
    }
};
</script>

<style lang="scss" scoped>
</style>
