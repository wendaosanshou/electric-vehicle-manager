# electric-vehicle-manager

## 安装依赖
```
npm install
```

### 开发模式下启动项目
```
npm run serve
```

### 编译并且打包
```
npm run build
```

## 访问地址
http://eriding.renownchn.com/web