export const $ajax = require('./ajax').default
export const $apis = require('./apis').default
export const $util = require('./util').default