<template>
  <div class="about">
  </div>
</template>

<script>
export default {};
</script>

<style lang="scss" scoped>
</style>
